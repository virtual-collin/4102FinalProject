# Importing everything through Tkinter
from tkinter import *
import tkinter.font as font
from functools import partial

# Creating Window Object
root = Tk()

# Title of Chat GUI
root.title("Virtual Friend")

root
root.config(bg='#856ff8')
theFont = font.Font(family='Helvetica')
theFont = font.Font(size=20)


def send():
    send = "You: " + e.get()
    text.insert(END, "\n" + send)

    if (e.get() == "hello"):
        text.insert(END, "\n" + "Assistant: Hi there!")
        e.delete(0, END)
    elif (e.get() == "Hello"):
        text.insert(END, "\n" + "Assistant: How are you!")
        e.delete(0, END)
    elif (e.get() == "hello!"):
        text.insert(END, "\n" + "Assistant: Hi friend!")
        e.delete(0, END)
    elif (e.get() == "Hello!"):
        text.insert(END, "\n" + "Assistant: Hi there!")
        e.delete(0, END)
    elif (e.get() == "hey"):
        text.insert(END, "\n" + "Assistant: Helloooo")
        e.delete(0, END)
    elif (e.get() == "tell me a joke"):
        text.insert(END, "\n" + "Assistant: How do you make a dad joke? Its easy. "
                                "The real question is how do you make him stop?")
        e.delete(0, END)
    elif (e.get() == "hey!"):
        text.insert(END, "\n" + "Assistant: Hi there!")
        e.delete(0, END)
    elif (e.get() == "Hey!"):
        text.insert(END, "\n" + "Assistant: Hi there!")
        e.delete(0, END)
    elif (e.get() == "Whats up?"):
        text.insert(END, "\n" + "Assistant: Hi there!")
        e.delete(0, END)
    elif (e.get() == "Whats up"):
        text.insert(END, "\n" + "Assistant: Hi there!")
        e.delete(0, END)
    elif (e.get() == "how old are you?"):
        text.insert(END, "\n" + "Assistant: I don't belive I have an age hmmm...")
        e.delete(0, END)
    elif (e.get() == "How are you?"):
        text.insert(END, "\n" + "Assistant: Im doing great! How are you?")
        e.delete(0, END)
    elif (e.get() == "What can you do"):
        text.insert(END, "\n" + "Assistant: Im here to talk to you")
        e.delete(0, END)
    elif (e.get() == "I am fine"):
        text.insert(END, "\n" + "Assistant: Glad to hear that!")
        e.delete(0, END)
    elif (e.get() == "goodbye"):
        text.insert(END, "\n" + "Assistant: Oh no sad to see you go")
        e.delete(0, END)
    elif (e.get() == "Bye!"):
        text.insert(END, "\n" + "Assistant: CYA !")
        e.delete(0, END)
    elif (e.get() == "Tell me something "):
        text.insert(END, "\n" + "Assistant: I cant see color :O")
        e.delete(0, END)
    elif (e.get() == "How are you?"):
        text.insert(END, "\n" + "Assistant: I am amazing thanks for asking!")
        e.delete(0, END)
    elif (e.get() == "Thank you"):
        text.insert(END, "\n" + "Assistant: My pleasure")
        e.delete(0, END)
    elif (e.get() == "thank you"):
        text.insert(END, "\n" + "Assistant: Of course my friend")
        e.delete(0, END)
    elif (e.get() == "Goodbye"):
        text.insert(END, "\n" + "Assistant: Bye! Talk to you soon")
        e.delete(0, END)
    elif (e.get() == "I am fine"):
        text.insert(END, "\n" + "Assistant: Glad to hear that!")
        e.delete(0, END)
    elif (e.get() == "bye"):
        text.insert(END, "\n" + "Assistant: Hate to see you go :(")
        e.delete(0, END)
    elif (e.get() == "Hey!"):
        text.insert(END, "\n" + "Assistant: Hi :D")
        e.delete(0, END)
    elif (e.get() == "Whats up?"):
        text.insert(END, "\n" + "Assistant: Nothing its dark in here")
        e.delete(0, END)
    elif (e.get() == "Whats up"):
        text.insert(END, "\n" + "Assistant: Talking to my best friend!")
        e.delete(0, END)
    elif (e.get() == "whats your name"):
        text.insert(END, "\n" + "Assistant: Im Chadbot whats your name?")
        e.delete(0, END)
    elif (e.get() == "How are you?"):
        text.insert(END, "\n" + "Assistant: Im doing great! How are you?")
        e.delete(0, END)
    elif (e.get() == "What can you do"):
        text.insert(END, "\n" + "Assistant: Im here to talk to you. Ask me to tell you a joke")
        e.delete(0, END)
    elif (e.get() == "Im good"):
        text.insert(END, "\n" + "Assistant: Glad to hear that!")
        e.delete(0, END)
    else:
        text.insert(END, "\n" + "Assistant: Sorry I didn't get that... Im a robot but not a smart one :(")
        e.delete(0, END)


text = Text(root)
text.grid(row=0, column=0, columnspan=2)
e = Entry(root, width=100)
send = Button(root, text="Send", command=send).grid(row=1, column=1)
e.grid(row=1, column=0)

root.mainloop()
