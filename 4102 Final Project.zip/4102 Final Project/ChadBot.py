# Importing everything through Tkinter
import tkinter as tk
from tkinter import *
import tkinter.font as font
from functools import partial
from tkinter import messagebox
import ChatGui


# Creating Window Object
root = Tk()
root.config(bg='#856ff8')
theFont = font.Font(family='Helvetica')
theFont = font.Font(size=14)
root.geometry('400x200')
root.title('Login')

def virtualAssistant():
    newWindow = root.Toplevel(ChatGui)




def getInfo():
    username = e.get()
    password = en.get()

    if username == "" and password == "":
        messagebox.showinfo("", "Please type in your Username and Password")

    elif username == "Uncc" and password == "Charlotte":
        messagebox.showinfo("", "Login Success")
        open(ChatGui)

    else:
        messagebox.showinfo("", "Incorrect Username and Password")


# username label and text entry box
Label(root, text="User Name").place(x=10, y=10)
Label(root, text="Password").place(x=10, y=40)

e = Entry(root)
e.place(x=140, y=10)

en = Entry(root)
en.place(x=140, y=40)
en.config(show="*")

Button(root, text="Login", command=getInfo, height=3, width=13).place(x=130, y=100)


root.mainloop()
